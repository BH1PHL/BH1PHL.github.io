#ifndef _INPUT_H
#define _INPUT_H


/** Wait for keypress on keyboard and return the code of the key.
 *  @return key code.
 */
int keyboard_getch(void);


/** This function tests if a key was pressed on the keyboard.
 *  @return nonzero when a key was pressed.
 */
int keyboard_hit(void);


#endif /* _INPUT_H */
