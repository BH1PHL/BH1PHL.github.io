This is a modified version of My4TH firmware and tools for I2C LCD keyboard and faster 
clock (up to 22.1184MHz).

Heading string: "ilk altes bxxx"

* "ilk" is the abbreviation for "I2C LCD Keyboard"
* "altes" for alternative EEPROM search
* "bxxx" for baud rate: "b144" is 14400, "b192" is 19200

Major changes (as of version fbde35e 241226):

Firmware:
* Alternative EEPROM search: Consecutive pages on one EEPROM chip 
  (24xx1026/BR24G1MFJ/M24M01 recommended), for external EEPROM cards
* Faster UART: 14400 baud at and above 16MHz, 19200 baud at 22.1184MHz
* Use PLD/PHD in words for performance
* Optimize tab_opcode for BLOAD modules with NFD extension 
* Tiny little debugs on PARSE, WORD and ADDRESS-UNIT-BITS in accordance with 
  Forth 2012 standard
* CH453 Keyboard and PCA9557 I2C LCD4004 Driver
* Modified key codes for CTRL keys
* Improve LIST for working with other I2C peripherals
* Improve LIST, DUMP and WORDS for auto pause on LCD
* Add word COLD for reset system at command line
* Change line number in EDIT and LIST to 0..15 in accordance with convensions

EDIT for LCD (m4-lcd-edit.bin):
* Shift+Up: up 4 lines
* Shift+Down: down 4 lines
* Shift+Left: return to line start
* Shift+Right: go to line end
* Ctrl+Enter: insert line after current line
* Shift+Enter: break current line
* Ctrl+C: Copy current line
* Ctrl+K: Delete(cut) current line
* Ctrl+U: Undelete(paste) a line
* Ctrl+Space: Clear current line
* Ctrl+Backspace: merge current line with previous line

my4th-tool:
* Custom baud rate at transfer and simulation


New words:
COLD	( -- )		\ Restart Forth system

KEY?	( -- f )	\ If a character is available, return true.
					\ Otherwise, return false.
					\ always blocks when at terminal

CR-W	( -- )	\ if at terminal, print newline; if at LCD, 
				\ pause every page and bypass when FIRSTLINE!=0;
				\ clear FIRSTLINE when called
FIRSTLINE	( -- addr_of_firstline )	\ use with C!/C@

CTRLOUTP	( -- addr_of_ctrloutp )	\ use with C!/C@
			\ CTRLOUTP: Mirror of PCA9557 at $3E out
			\ bit 6,5,4 is LCD select (for 4004A, 0=E1, 1=E2)
			\ bit 3 is backlight
			\ if use IO17, save status in CTRLOUTP

I2C-WR  ( content regnum addr -- flag ) \ write I2C register. successful: flag=0
I2C-RR ( regnum addr -- val flag ) \ read I2C register. successful: flag=0
CH453-WR ( content regaddr -- flag ) \ write CH453 register. successful: flag=0    

LCD	( -- )			\ switch to LCD display
TERMINAL	( -- )	\ switch to terminal


---

Original firmware by D. Kuschel (http://mynor.org/my4th.htm), 2023-2024.
Modified by BH1PHL (https://qsl.net/bh1phl/), 2024-2025.

My4TH hardware and software is licensed under CC BY-SA 4.0. 
Cross assembler "myca" is licensed under GPLv3.