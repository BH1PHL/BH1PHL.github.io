
How to build the My4TH EPROM image from the source code
=======================================================

To build this ROM you must have the latest version of MyCA (my cross assembler) installed on your system.

Build the My4TH operating system with:

# myca my4th-rom_8MHz.asm -o my4th-rom.bin -l

This will give you the binary program that must be copied into the EPROM at start address 0x2D00.
To generate the 32kB EPROM image file that includes the image above and the microcode, you must have
the tool "my4th" installed on your system. Enter this command to generate the EPROM image:

# my4th -r my4th-rom.bin -w 0,0x7fff,my4th-eprom-image.bin

The generated file my4th-eprom-image.bin can be programmend into the 27C256 EPROM.


If you are using Linux, you can also execute the script build.sh. The script builds
all available versions at once. The generated output can be found in the output subdirectrory.

If you have any questions please contact me:  dennis_k@freenet.de / www.mynor.org
