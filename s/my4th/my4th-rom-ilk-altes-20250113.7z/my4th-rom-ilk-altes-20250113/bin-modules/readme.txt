
Binary extension modules for the My4TH computer
===============================================

This zip-file contains:

  m4-strings.bin    - Forth 2012 String words, binary module
  m4-strings.asm    - Forth 2012 String words, source code
  m4-facility.bin   - Forth 2012 Facility extension words, binary module
  m4-facility.asm   - Forth 2012 Facility extension words, source code
  m4-float.bin      - Forth 2012 Floating-Point word set, binary module
  m4-float.asm      - Forth 2012 Floating-Point word set, source code
  m4-forthdeck.asm  - Driver for the Forth Deck with the nfd-ROM


Use the my4th transfer tool in binary mode to upload the .bin file to your
My4TH computer. For example, to upload m4-float.bin to EEPROM block 20
and following, enter:

  $ my4th write /dev/ttyS0 binary 20 m4-float.bin

On My4TH, enter this command to load and install the floating point word set:

 20 BLOAD




Word Lists
==========

m4-strings:

  BLANK            CMOVE            CMOVE>           COMPARE
  /STRING          -TRAILING        SEARCH           SLITERAL


m4-facility:

  BEGIN-STRUCTURE  EKEY>CHAR        K-RIGHT          K-F2
  END-STRUCTURE    EKEY>FKEY        K-END            K-F3
  +FIELD           EMIT?            K-HOME           K-F4
  FIELD:           K-DELETE         K-INSERT         K-F5
  CFIELD:          K-DOWN           K-NEXT           K-F6
  EKEY             K-UP             K-PRIOR          K-F7
  EKEY?            K-LEFT           K-F1             K-F8


m4-float:

  >FLOAT           FALIGNED         FROT             FEXP
  D>F              FCONSTANT        FROUND           FFIELD:
  F!               FDEPTH           FSWAP            FLN
  F*               FDROP            FVARIABLE        FLOG
  F+               FDUP             REPRESENT        FS.
  F-               FLITERAL         F.               FSIN
  F/               FLOAT+           F>S              FSQRT
  F0<              FLOATS           FABS             FTAN
  F0=              FLOOR            FACOS            FTRUNC
  F<               FMAX             FASIN            FVALUE
  F>D              FMIN             FATAN            PRECISION
  F@               FNEGATE          FCOS             S>F
  FALIGN           FOVER            FE.              SET-PRECISION

  Note: The floating point arithmetic is very slow and inaccurate on My4TH!




Version Information and Change Log
==================================

  m4-strings.bin   :  v1.0
  m4-facility.bin  :  v1.0
  m4-float.bin     :  v1.0
  m4-forthdeck.asm :  v1.0

Change Log:
  (nothing yet)



(C) Dennis Kuschel, dennis_k@freenet.de, www.mynor.org
