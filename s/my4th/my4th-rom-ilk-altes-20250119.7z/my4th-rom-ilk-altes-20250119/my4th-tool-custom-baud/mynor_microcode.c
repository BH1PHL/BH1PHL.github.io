#define ARCH_MYNOR
#include "my4th_microcode.c"
