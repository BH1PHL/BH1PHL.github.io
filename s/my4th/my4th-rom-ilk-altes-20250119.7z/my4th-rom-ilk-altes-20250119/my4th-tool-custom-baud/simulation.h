#ifndef _SIMULATION_H
#define _SIMULATION_H

#include <stdint.h>


#define LOW  ((signal_t)0)
#define HIGH ((signal_t)1)

typedef int      signal_t;
typedef uint8_t  dbus_t;
typedef uint16_t abus_t;

typedef void    (*iowritecb_t)(uint8_t data);
typedef uint8_t (*ioreadcb_t)(void);


#endif /* _SIMULATION_H */
