
The My4TH-nfd ROM is equivalent to the original My4TH ROM, but without support for the Forth Deck.
Instead, it includes some extra features:

  - lightning-fast data stack, Forth programs now run 30% to 100% faster than before
  - increased compilation speed
  - faster I2C bus (approx. 3x speed compared to the original My4TH firmware)
  - improved the output of "dump", bytes are now also shown as ASCII characters
  - improved line editing at the command prompt (e.g. support for inserting characters)
  - improved built-in text editor

