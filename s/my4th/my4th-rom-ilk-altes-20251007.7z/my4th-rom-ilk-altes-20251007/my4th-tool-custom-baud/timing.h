#ifndef _TIMING_H
#define _TIMING_H

#include <stdint.h>


#define TIMING_GRID   10000000  /* 10 ms */


/* Get 32-bit microseconds-counter */
uint32_t get_usec(void);


/* Check if time is over */
int isTimeOver(uint32_t *timer, uint32_t exptime, uint32_t now, uint32_t *rem);


/* Timing Control */
void sleep_until_next_timing_grid(void);


/* Sleep some milliseconds */
void sleep_msec(uint32_t msec);


#endif
