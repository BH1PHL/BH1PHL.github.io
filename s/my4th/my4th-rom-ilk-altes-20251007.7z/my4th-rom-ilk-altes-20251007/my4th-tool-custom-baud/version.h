
#define VER_VERSION  "1.2"
#define VER_YEAR     "2023"
#define VER_URL      "www.mynor.org"
