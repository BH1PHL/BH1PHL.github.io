
**** This is My4TH **** by Dennis Kuschel **** www.mynor.org **** dennis_k@freenet.de ****


Archive Contents
----------------

This archive contains EPROM images for all flavours of the My4TH boards
as binary files and also the corresponding source code:

    my4th/          -- ROMs for the white My4TH board, with support for the Forth Deck
    my4th-nfd/      -- ROMs for the white My4TH board, much faster program execution
    mynor/          -- ROMs for the MyNOR board (this is My4TH Forth for the MyNOR board)
    my4th-light/    -- ROMs for the yellow My4TH light board
    my4th-xs/       -- ROMs for the red My4TH XS board
    readme.txt      -- this file
    LICENSE.txt     -- the license text of the Creative Commons License
    source.zip      -- ZIP archive with the source code
    listfiles.zip   -- ZIP archive with all the assembler list files of all ROMs



What is My4TH-nfd?
------------------

My4TH-nfd is an alternative firmware for the white My4TH board. It is equivalent to
the original firmware, but it has no support for the Forth Deck. Instead, it includes
some extra features:

  - much faster program execution (min. 30% faster than the original My4TH ROM)
  - faster I2C bus (approx. 3x speed compared to the original My4TH ROM)
  - improved line editing at the command prompt (e.g. support for inserting characters)
  - improved built-in text editor

Note:
The My4TH-nfd ROM can also be used with the Forth Deck if an additional driver is
loaded from the EEPROM. Please read the readme file in the my4th-nfd directory for details.



License
-------

My4TH hardware and software is licensed under the
'Creative Commons Attribution-ShareAlike 4.0' license.
