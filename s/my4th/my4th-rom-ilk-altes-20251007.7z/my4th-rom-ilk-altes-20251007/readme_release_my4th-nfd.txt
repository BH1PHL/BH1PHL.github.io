*******************************************************************************
**                                                                           **
**  This is the My4TH ROM for the white My4TH board without support          **
**  for the Forth Deck (nfd = "no Forth Deck").                              **
**                                                                           **
**  This ROM includes special features such as a much faster data stack,     **
**  a faster I2C interface, better line-editing functions, and an improved   **
**  text editor. Overall, your programs will run faster with the nfd ROM.    **
**                                                                           **
**  Platform :  white My4TH board                                            **
**  Version  :  1.4                                                          **
**  Developer:  Dennis Kuschel                                               **
**  eMail    :  dennis_k@freenet.de                                          **
**  Website  :  www.mynor.org/my4th                                          **
**                                                                           **
*******************************************************************************


This directory contains several EPROM image files. You must select the file
that matches the frequency of the oscillator on your board.

    my4th-nfd-rom_8MHz_v1.4.bin   -- binary My4TH EPROM image file for 8 MHz operation
    my4th-nfd-rom_10MHz_v1.4.bin  -- binary My4TH EPROM image file for 10 MHz operation
    my4th-nfd-rom_12MHz_v1.4.bin  -- binary My4TH EPROM image file for 12 MHz operation
    my4th-nfd-rom_14MHz_v1.4.bin  -- binary My4TH EPROM image file for 14 MHz operation
    m4-forthdeck.bin              -- driver for the Forth Deck



Build Instructions
------------------

To build the source code, extract the source code archive,
change into the "source" directory and execute:
  
  # myca my4th-nfd-rom_8MHz.asm -o my4th-nfd-rom.bin -l
  
To generate the EPROM image file, execute:

  # my4th -r my4th-nfd-rom.bin -w 0,0x7fff,my4th-nfd-rom_8MHz_v1.4.bin



How to use this ROM with the Forth Deck
---------------------------------------

It is also possible to use this ROM with the Forth Deck, although the ROM
has no built-in support for this. Instead, you will need to load a special
driver from EEPROM if you want to use this nfd-ROM with your Forth Deck.

Follow these steps to install the driver on your My4TH system:

  1.  Copy the file m4-forthdeck.bin to (for example) blocks 60 to 63
      using the my4th transfer tool:
        $ my4th write /dev/ttyS0 binary 60 m4-forthdeck.bin

  2.  Setup your My4TH board to autostart screen 1:
      Edit screen 0 and write the number "1" at the beginning of line 1.
  
  3.  Edit screen 1, clear it and write these words into line 1:
        $2D1E execute 60 bload
      The term "$2D1E execute" is optional, it only displays a "booting"
      message when the Forth Deck is switched on.



My4TH-nfd ROM Version History
-----------------------------

ROM v1.4
--------
  initial version based on My4TH ROM v1.4, which includes these updates:
  - fixed error handling in BLOCK words and in I2C-START word
  - fixed two minor bugs in the input-line routine (editor and command line)
  - fixed a bug in the 32-bit multiplication routine that only affected negative numbers
  - improved the output of "words", newly defined words are now printed last
  - improved the text editor, lines are edited inside the screen window now
  - added support for number prefixes [%#$], example: $14 = #20 = %10100
  - added support for underscore within numbers, example: %1001_0011
  functions removed from My4TH ROM v1.4:
  - no support for LCD and keyboard, so this ROM is not suited for the Forth Deck
  additional new features:
  - lightning-fast data stack, Forth programs now run 30% to 100% faster than before
  - increased compilation speed
  - faster I2C bus (approx. 3x speed compared to the original My4TH firmware)
  - improved the output of "dump", bytes are now also shown as ASCII characters
  - improved line editing at the command prompt (e.g. support for inserting characters)
  - improved built-in text editor
